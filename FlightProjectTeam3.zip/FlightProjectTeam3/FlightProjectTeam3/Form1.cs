﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IBM.Data.DB2.iSeries;

namespace FlightProjectTeam3
{
    public partial class Form1 : Form
    {
        iDB2Connection connection;
        iDB2Command command;
        iDB2DataReader reader;
        string promptValue;
        string SQL1;
        string SQL2;
        string SQL3;
        string SQL4;
        string SQL5;
        string connectionstring;
        public Form1()
        {   
            InitializeComponent();
            connectionstring = "DataSource = deathstar.gtc.edu;DefaultCollection=FLIGHT2019";
            connection = new iDB2Connection(connectionstring);
         
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDispCust_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            try
            {
                SQL1 = "SELECT * FROM CUSTOMER";
                command = new iDB2Command(SQL1, connection);
                connection.Open();

                reader = command.ExecuteReader();

                while (reader.Read())
                    listBox1.Items.Add(reader.GetString(1) + " " + reader.GetString(2));
                connection.Close();
            }
            catch(Exception iex)
            {
                listBox1.Items.Add(iex.Message);
            }
        }

        private void btnFltCust_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            promptValue = ansInput.ShowDialog("Enter Flight Number", "Database Retreival");
            try
            {
                string textboxValue = txt1.Text;
                SQL2 = "SELECT CUSTOMERS, RESRVTN" +
                               "FROM dbo.employee " +
                               "WHERE name LIKE '" + promptValue + "'";
                command = new iDB2Command(SQL2, connection);
                connection.Open();

                reader = command.ExecuteReader();

                while (reader.Read())
                    listBox1.Items.Add(reader.GetString(1) + " " + reader.GetString(2));
                connection.Close();
            }
            catch (Exception iex)
            {
                listBox1.Items.Add(iex.Message);
            }
        }

        private void displayCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            try
            {
                SQL1 = "SELECT * FROM CUSTOMER";
                command = new iDB2Command(SQL1, connection);
                connection.Open();

                reader = command.ExecuteReader();

                while (reader.Read())
                    listBox1.Items.Add(reader.GetString(1) + " " + reader.GetString(2));
                connection.Close();
            }
            catch (Exception iex)
            {
                listBox1.Items.Add(iex.Message);
            }
        }
    }
}
